const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const box = 20;
const canvasSize = 400;
let snake, food, score, level, health, applesEaten, direction, game, gameStarted;
let goldenAppleActive = false;

function resetGame() {
    snake = [{ x: 9 * box, y: 10 * box }];
    score = 0;
    level = 1;
    health = 5;
    applesEaten = 0;
    direction = null;  
    gameStarted = false;
    goldenAppleActive = false;

    food = {
        x: Math.floor(Math.random() * (canvasSize / box)) * box,
        y: Math.floor(Math.random() * (canvasSize / box)) * box
    };

    clearInterval(game);  
    updateUI(); 
}

document.addEventListener("keydown", changeDirection);

function changeDirection(event) {
    const key = event.keyCode;
    if (key === 37 && direction !== "RIGHT") direction = "LEFT";
    if (key === 38 && direction !== "DOWN") direction = "UP";
    if (key === 39 && direction !== "LEFT") direction = "RIGHT";
    if (key === 40 && direction !== "UP") direction = "DOWN";

    if (!gameStarted) {
        gameStarted = true;
        game = setInterval(draw, 100);  
    }
}

function draw() {
    if (!direction) return;  
    ctx.clearRect(0, 0, canvasSize, canvasSize);

    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = (i === 0) ? "#00FF00" : "#fff";
        ctx.fillRect(snake[i].x, snake[i].y, box, box);
        ctx.strokeStyle = "#ff4081";
        ctx.strokeRect(snake[i].x, snake[i].y, box, box);
    }

    ctx.fillStyle = goldenAppleActive ? "gold" : "red";
    ctx.fillRect(food.x, food.y, box, box);

    let snakeX = snake[0].x;
    let snakeY = snake[0].y;

    if (direction === "LEFT") snakeX -= box;
    if (direction === "UP") snakeY -= box;
    if (direction === "RIGHT") snakeX += box;
    if (direction === "DOWN") snakeY += box;

    if (snakeX === food.x && snakeY === food.y) {
        score++;
        applesEaten++;

        if (goldenAppleActive) {
            health += 2;
            goldenAppleActive = false;
        }

        if (applesEaten % 10 === 0) {
            goldenAppleActive = true;
        }

        food = {
            x: Math.floor(Math.random() * (canvasSize / box)) * box,
            y: Math.floor(Math.random() * (canvasSize / box)) * box
        };

        if (applesEaten % 10 === 0) {
            level++;
        }
    } else {
        snake.pop();
    }

    let newHead = { x: snakeX, y: snakeY };

    if (snakeX < 0 || snakeY < 0 || snakeX >= canvasSize || snakeY >= canvasSize || collision(newHead, snake)) {
        health--;
        if (health <= 0) {
            resetGame();  
        } else {
            snake = [{ x: 9 * box, y: 10 * box }];
            direction = null;  
            gameStarted = false;  
        }
    }

    snake.unshift(newHead);

    updateUI();
}

function updateUI() {
    document.getElementById("score").innerText = `Score: ${score}`;
    document.getElementById("level").innerText = `Level: ${level}`;
    document.getElementById("health").innerText = "❤️".repeat(health);
}

function collision(head, array) {
    for (let i = 0; i < array.length; i++) {
        if (head.x === array[i].x && head.y === array[i].y) {
            return true;
        }
    }
    return false;
}

resetGame();
